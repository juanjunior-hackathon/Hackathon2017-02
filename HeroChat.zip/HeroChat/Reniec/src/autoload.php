<?php
	require (__DIR__ . "/curl.php");
	require (__DIR__ . "/solver.php");
	require (__DIR__ . "/reniec.php");
?>
