<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name = "viewport" content = "initial-scale = 1.0, user-scalable = no,  width=device-width">
		<title>Consulta RENIEC sin Captcha Perú - GeekDev</title>
		<meta name="description" content="Consulta RENIEC sin Captcha Perú, descarga este codigo desde demos.geekdev.ml"/>
		<meta name="keywords" content="buscar dni, consultar dni peru, api rest consulta dni peru, reniec perú, consulta dni sin captcha, dni reniec 2017"/>
		<meta property="og:locale" content="es_PE" />
		<meta property="og:type" content="website" />
		<meta property="og:title" content="Consulta de DNI RENIEC sin Captcha Perú - GeekDev" />
		<meta property="og:description" content="Consulta RENIEC sin Captcha Perú, descarga este codigo desde demos.geekdev.ml" />
		<meta property="og:image" content="https://drive.google.com/uc?id=0BxTe_c1GIOkoSmtJMFZNRi1mNWs&export=view" />
		<!-- Bootstrap -->
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">

		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

		<style type="text/css">
			h1{
				margin:0px;
				padding:0px;
			}
		</style>
	</head>
	<body style="background-color:#f5f5f5;">
		<div class="container">
			<h1 class="text-center p-3">Consulta DNI</h1>
			<form class="form-horizontal" role="form" method="post" name="busqueda" id="busqueda" >
			<div class="card border-info">
				<div class="card-header bg-info text-center text-light">
					Ingrese los datos requeridos
				</div>
				<div class="card-body">
					<input type="number" class="form-control" name="ndni" id="ndni" placeholder="Ingrese DNI" pattern="([0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9])" autofocus>
				</div>
				<div class="card-footer text-center">
					<button type="submit" class="btn btn-success" name="btn-submit" id="btn-submit">
						<i class="fa fa-search"></i> Buscar
					</button>
				</div>
			</div>
			</form>
				
			<div class="result">
				<ul class="nav nav-tabs" role="tablist">
					<li class="nav-item">
						<a class="nav-link active" href="#home" data-toggle="tab" role="tab">Respuesta</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#json" data-toggle="tab" role="tab">Json</a>
					</li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="home" role="tabpanel">
						<div class="card border-info" id="home">
							<div class="card-body">
								<form class="form-horizontal row" name="FormData" id="FormData" style="border-right:1px solid white;">
									<div class="form-group col-10">
										<label for="Nombre">Tu DNI:</label>
										<input type="text" class="form-control" id="DNI" placeholder="DNI">
									</div>
									<div class="form-group col-2">
										<label for="CodVerificacion">Tu Cod. Validacion:</label>
										<input type="text" class="form-control" id="CodVerificacion" placeholder="Cod. Verificacion">
									</div>
									<div class="form-group col-12">
										<label for="Nombre">Tu Nombre:</label>
										<input type="text" class="form-control" id="Nombre" placeholder="Tu Nombres">
									</div>
									<div class="form-group col-12">
										<label for="Paterno">Tu Paterno:</label>
										<input type="text" class="form-control" id="Paterno" placeholder="Tu Apellido Paterno">
									</div>
									<div class="form-group col-12">
										<label for="Materno" >Tu Materno:</label>
										<input type="text" class="form-control" id="Materno" placeholder="Tu Apellido Materno">
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div style="display:none" class="alert alert-danger" role="alert" id="error">
			</div>
			<footer class="footer text-center">
				<div class="col">
					<p><small>&copy; 2015 - 2017 JossMP - Derechos Reservados</small></p>
				</div>
			</footer>
		</div>
		<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
		<script src="js/ajaxview.js"></script>
		<script>
			$(document).ready(function(){
				$("#btn-submit").click(function(e){
					var $this = $(this);
					e.preventDefault();
					//$this.button('loading');
					$.ajaxblock();
					$.ajax({
						data: { "ndni" : $("#ndni").val() },
						type: "POST",
						dataType: "json",
						url: "consulta.php",
					}).done(function( data, textStatus, jqXHR ){
						if(data['success']!="false" && data['success']!=false)
						{
							$("#json_code").text(JSON.stringify(data, null, '\t'));
							if(typeof(data['result'])!='undefined')
							{
								$("#CodVerificacion").val( data["result"]["CodVerificacion"] );
								$("#DNI").val( data["result"]["Tu DNI"] );
								$("#Nombre").val( data["result"]["Tu Nombre"] );
								$("#Materno").val( data["result"]["Tu Materno"] );
								$("#Paterno").val( data["result"]["Tu Paterno"] );
							}
							//$this.button('reset');
							$.ajaxunblock();
						}
						else
						{
							if(typeof(data['msg'])!='undefined')
							{
								alert( data['msg'] );
							}
							//$this.button('reset');
							$.ajaxunblock();
						}
					}).fail(function( jqXHR, textStatus, errorThrown ){
						alert( "Solicitud fallida:" + textStatus );
						$this.button('reset');
						$.ajaxunblock();
					});
				});
			});
		</script>
	</body>
</html>
