<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name = "viewport" content = "initial-scale = 1.0, user-scalable = no,  width=device-width">
		<title>Consulta RENIEC sin Captcha Perú - GeekDev</title>
		<meta name="description" content="Consulta RENIEC sin Captcha Perú, descarga este codigo desde demos.geekdev.ml"/>
		<meta name="keywords" content="buscar dni, consultar dni peru, api rest consulta dni peru, reniec perú, consulta dni sin captcha, dni reniec 2017"/>
		<meta property="og:locale" content="es_PE" />
		<meta property="og:type" content="website" />
		<meta property="og:title" content="Consulta de DNI RENIEC sin Captcha Perú - GeekDev" />
		<meta property="og:description" content="Consulta RENIEC sin Captcha Perú, descarga este codigo desde demos.geekdev.ml" />
		<!--<meta property="og:image" content="https://drive.google.com/uc?id=0BxTe_c1GIOkoSmtJMFZNRi1mNWs&export=view" />-->
		<!-- Bootstrap -->
		<!-- Latest compiled and minified CSS -->
	<link href="../../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
    <!-- Libraries CSS Files -->
    <link href="../../lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">

		<style type="text/css">
			h1{
				margin:0px;
				padding:0px;
			}
		</style>

	</head>
	<body style="background-color:#f5f5f5;">
		<br/>
		<br/>

		<div class="container">
			<form class="form-horizontal" role="form" method="post" name="busqueda" id="busqueda" >
			<div class="card">
				<div class="card-header text-center text-light" style="background-color:#1470b9;">
					<h5 class="text-center p-3" style="color:white;">Hola amig@ Ciudadan@, Ingresa tu DNI para verificar tu Información !</h5>
				</div>
				<div class="card-body" style="display:inline-flex;">
					<input type="number" class="form-control" name="ndni" id="ndni" style="font-weight:700;color:#8a8a8a;" placeholder="Ingresar tu DNI, para iniciar el chat por favor." pattern="([0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9])" autofocus>
					<button type="submit" class="btn btn-success" name="btn-submit" id="btn-submit">
						<i class="fa fa-search"></i> Buscar DNI
					</button>
		<!--			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
										  Buscar
					</button>-->
				</div>
			</div>
			</form>
			
			<div style="display:none" class="result">
				<ul class="nav nav-tabs" role="tablist">
					<li class="nav-item">
						<a class="nav-link active" href="#home" data-toggle="tab" role="tab">Gracias por brindar tu DNI para iniciar el chat</a>
					</li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="home" role="tabpanel">
						<div class="card border-info" id="home">
							<div class="card-body">
								<table class="table table-striped" style="border-right:1px solid white;">								
									<tbody id="tbody">
									</tbody>
									<br/>
									<div class="form-group col-12" style="text-align:center;">
										<img alt="Bell - A perfect theme" class="gadgets-img hidden-md-down" style="width:50px;" src="../../img/mensajero.png">
										<a style="background-color:#448aff;border-color:#448aff;" href="https://www.messenger.com/t/815953785243798" class="btn btn-success">
											<i class="fa fa-wechat"></i> Click y Chatea !
										</a>
									</div>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
			<div style="display:none" class="alert alert-danger" role="alert" id="error">
			</div>
			<footer class="footer text-center">
				<div class="col">
					<p><small>&copy; 2017 Hero Chat - Derechos Reservados</small></p>
				</div>
			</footer>
		</div>
		<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
		<script src="js/ajaxview.js"></script>
		<script>
			$(document).ready(function(){
				$("#btn-submit").click(function(e){
					var $this = $(this);
					e.preventDefault();
					//$this.button('loading');
					$.ajaxblock();
					$.ajax({
						data: { "ndni" : $("#ndni").val() },
						type: "POST",
						dataType: "json",
						url: "consulta.php",
					}).done(function( data, textStatus, jqXHR ){
						if(data['success']!="false" && data['success']!=false)
						{
							$("#json_code").text(JSON.stringify(data, null, '\t'));
							if(typeof(data['result'])!='undefined')
							{
								$("#tbody").html("");
								$.each(data['result'], function(i, v)
								{
									$("#tbody").append('<tr><td>'+i+'<\/td><td>'+v+'<\/td><\/tr>');
								});
							}
							//$this.button('reset');
							$("#error").hide();
							$(".result").show();
							$.ajaxunblock();
						}
						else
						{
							if(typeof(data['msg'])!='undefined')
							{
								alert( data['msg'] );
							}
							//$this.button('reset');
							$.ajaxunblock();
						}
					}).fail(function( jqXHR, textStatus, errorThrown ){
						alert( "Solicitud fallida:" + textStatus );
						$this.button('reset');
						$.ajaxunblock();
					});
				});
			});
		</script>
	</body>
</html>
