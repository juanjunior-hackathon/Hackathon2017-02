<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Hero Chat</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    
    <!-- Facebook Opengraph integration: https://developers.facebook.com/docs/sharing/opengraph -->
    <meta property="og:title" content="">
    <meta property="og:image" content="">
    <meta property="og:url" content="">
    <meta property="og:site_name" content="">
    <meta property="og:description" content="">
    
    <!-- Twitter Cards integration: https://dev.twitter.com/cards/  -->
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="">
    <meta name="twitter:title" content="">
    <meta name="twitter:description" content="">
    <meta name="twitter:image" content="">

    <!-- Favicon -->
    <link href="img/Captura.JPG" rel="icon">
  
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,700|Roboto:400,900" rel="stylesheet">
    
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    
    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">
    
    <!-- =======================================================
      Theme Name: Bell
      Theme URL: https://bootstrapmade.com/bell-free-bootstrap-4-template/
      Author: BootstrapMade.com
      Author URL: https://bootstrapmade.com
    ======================================================= -->
    <!--Start of Zendesk Chat Script-->
<!--Start of Zendesk Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
$.src="https://v2.zopim.com/?5K6wZtEtNvGZzf3ONVT3kmAC9xyO0AJ0";z.t=+new Date;$.
type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
</script>
<!--End of Zendesk Chat Script-->
  </head>

  <body>
    <!-- Page Content
    ================================================== -->
    <!-- Hero -->
  <!-- Header -->
  <header id="header">
    <div class="container">
    
      <div id="logo" class="pull-left">
              <x style="font-weight:700;font-size:30px;color:#FF9800;"> Hero </x>
              <x style="font-weight:700;font-size:30px;color:white;"> Chat </x>
      </div>
        
      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li><a style="font-size:20px;" href="#about">Inicio</a></li>
          <li><a style="font-size:20px;" href="#about">Como Funciona</a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
      
      <nav class="nav social-nav pull-right hidden-sm-down">
        <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-envelope"></i></a>
      </nav>
    </div>
  </header><!-- #header -->
    <section class="hero">
      <div class="container text-center">
        <div class="row">
          <div class="col-md-12">
            <a class="hero-brand" title="Home">
              <x style="font-weight:700;font-size:60px;color:#FF9800;"> Hero </x>
              <x style="font-weight:700;font-size:60px;color:white;"> Chat</x>
            </a>
          </div>
        </div>

        <div class="col-md-12">
          <h1>
            Seguridad Ciudadana
          </h1>

          <p class="tagline">
            Reporta y recibe respuestas en tiempo real, para tu cuidado ciudadano.
          </p>
          <a class="btn btn-full" href="Reniec/example/">Ingresar a Chat</a>

        </div>
      </div>
      
    </section>

    <!-- /Hero -->

  
    <!-- About -->

    <section class="about" id="about">
      <div class="container text-center">
        <h2>
          Nosotros Pensamos en ti
        </h2>

        <p>
          Asesoria de denuncia, contactos de los servicios de seguridad publica, calificación de seguridad de la zona y reporte de incidencia
        </p>

      <div class="row stats-row">
          <div class="stats-col text-center col-md-6 col-sm-6">
            <div class="circle">
              Chat en Tiempo Real
            </div>
          </div>

          <div class="stats-col text-center col-md-6 col-sm-6">
            <div class="circle">
              Comunicación las 24 horas
            </div>
          </div>

        </div>
      </div>
    </section>
    <!-- /About -->
    <!-- Parallax -->

    <div class="block bg-primary block-pd-lg block-bg-overlay text-center" data-bg-img="img/parallax-bg.jpg" data-settings='{"stellar-background-ratio": 0.6}' data-toggle="parallax-bg">
      <h2>

      </h2>

      <p>
        Unete al cambio y educate en seguridad ciudadana
      </p>
      <img alt="Bell - A perfect theme" class="gadgets-img hidden-md-down" src="img/gadgets.png">
    </div>
    <!-- /Parallax -->
    <!-- Features -->

    <section class="features" id="features">
      <div class="container">
        <div class="row">


          <div class="feature-col col-lg-6 col-xs-12">
            <div class="card card-block text-center">
              <div>
                <p>
                  <img alt="Bell - A perfect theme" style="width:80%;" class="gadgets-img hidden-md-down" src="img/imgapp1.png">
                </p>
              </div>
            </div>
          </div>

          <div class="feature-col col-lg-6 col-xs-12">
            <div class="card card-block text-center">
              <div>
                <p>
                  <img alt="Bell - A perfect theme" style="width:80%;" class="gadgets-img hidden-md-down" src="img/imgapp2.png">
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>

    <section class="features" id="features" style="background-color:whitesmoke;">
      <div class="container">
        <h2 class="text-center">
          Nuestros Servicios
        </h2>

        <div class="row">
          <div class="feature-col col-lg-4 col-xs-12" style="background-color:whitesmoke;">
            <div class="card card-block text-center" style="background-color:whitesmoke;">
              <div>
                <div class="feature-icon">
                  <span class="fa fa-rocket"></span>
                </div>
              </div>

              <div>
                <h3>
                  Comunicación en tiempo Real para consultas
                </h3>

                <p>
                  Nos comunicamos contigo para tu permanencia de cuidado ciudadano.
                </p>
              </div>
            </div>
          </div>

          <div class="feature-col col-lg-4 col-xs-12" style="background-color:whitesmoke;">
            <div class="card card-block text-center" style="background-color:whitesmoke;">
              <div>
                <div class="feature-icon">
                  <span class="fa fa-envelope"></span>
                </div>
              </div>

              <div>
                <h3>
                  Información de entididades de seguridad ciudadana
                </h3>
                <p>
                  Te brindamos información de teléfonos de tus centros de seguridad ciudadana.
                </p>
              </div>
            </div>
          </div>

          <div class="feature-col col-lg-4 col-xs-12" style="background-color:whitesmoke;">
            <div class="card card-block text-center" style="background-color:whitesmoke;">
              <div>
                <div class="feature-icon">
                  <span class="fa fa-bell"></span>
                </div>
              </div>

              <div>
                <h3>
                  Formate en seguridad ciudadana.
                </h3>
                <p>
                 Te brindamos una herramienta para que te eduques constantemente.
                </p>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
    </section>

    <section id="contact">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h2 class="section-title">Envianos un mensaje</h2>
          </div>
        </div>
        
        <div class="row">
          <div class="col-lg-3 offset-lg-2">
            <div class="info">
              <div>
                <!--<object allowscriptaccess="always" type="application/x-shockwave-flash" data="http://images2.flashobject.info/site.swf?id=1610788&ln=es" width="200" height="200" wmode="transparent"><param name="allowscriptaccess" value="always" /><param name="movie" value="http://images2.flashobject.info/site.swf?id=1610788&ln=es" /><param name="wmode" value="transparent" /><embed src="http://images2.flashobject.info/site.swf?id=1610788&ln=es" type="application/x-shockwave-flash" allowscriptaccess="always" wmode="transparent" width="200" height="200" /><video width="200" height="200"><a href="http://www.fxnihon.com/iforex8.html" style="text-decoration:underline;font-style:normal;font-weight:normal" title="バイナリー">バイナリー</a></video></object>-->
              </div>
             
              <div>
                <i class="fa fa-map-marker"></i>
                <p>A108 Adam Street<br>New York, NY 535022</p>
              </div>
              
              <div>
                <i class="fa fa-envelope"></i>
                <p>info@example.com</p>
              </div>
              
              <div>
                <i class="fa fa-phone"></i>
                <p>+1 5589 55488 55s</p>
              </div>
            
            </div>
          </div>
          
          <div class="col-lg-5">
            <div class="form">
              <div id="sendmessage">Tu mensaje se envio correctamente, muchas gracias!</div>
              <div id="errormessage"></div>
              <form action="" method="post" role="form" class="contactForm">
                  <div class="form-group">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Tus Nombres" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    <div class="validation"></div>
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control" name="email" id="email" placeholder="Tu Email" data-rule="email" data-msg="Please enter a valid email" />
                    <div class="validation"></div>
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Tema" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                    <div class="validation"></div>
                  </div>
                  <div class="form-group">
                    <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Escribenos tu mensaje" placeholder="Escribe tu Mensaje"></textarea>
                    <div class="validation"></div>
                  </div>
                  <div class="text-center"><button type="submit">Enviar Mensaje</button></div>
              </form>
            </div>
          </div>
          
        </div>
      </div>
    </section>
      
    <footer class="site-footer">
      <div class="bottom">
        <div class="container">
          <div class="row">

            <div class="col-lg-6 col-xs-12 text-lg-left text-center">
              <p class="copyright-text">
                © Hero Chat
              </p>
              <div class="credits">   
                  <!-- 
                  All the links in the footer should remain intact. 
                  You can delete the links only if you purchased the pro version.
                  Licensing information: https://bootstrapmade.com/license/
                  Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Bell
                -->
              </div>
            </div>
            
            <div class="col-lg-6 col-xs-12 text-lg-right text-center">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <a>Inicio</a>
                </li>

                <li class="list-inline-item">
                  <a>Misión y Visión</a>
                </li>

                <li class="list-inline-item">
                  <a>Objetivos</a>
                </li>

                <li class="list-inline-item">
                  <a>Quienes Somos ?</a>
                </li>

              </ul>
            </div>
            
          </div>
        </div>
      </div>
    </footer>
    <a class="scrolltop" href="#"><span class="fa fa-angle-up"></span></a> <!-- JavaScript


    <!-- Required JavaScript Libraries -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/superfish/hoverIntent.js"></script>
    <script src="lib/superfish/superfish.min.js"></script>
    <script src="lib/tether/js/tether.min.js"></script>
    <script src="lib/stellar/stellar.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/easing/easing.js"></script>
    <script src="lib/stickyjs/sticky.js"></script>
    <script src="lib/parallax/parallax.js"></script>
    <script src="lib/lockfixed/lockfixed.min.js"></script>
    
    <!-- Template Specisifc Custom Javascript File -->
    <script src="js/custom.js"></script>
    
    <script src="contactform/contactform.js"></script>
    
        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    <script src="Reniec/example/js/ajaxview.js"></script>
    <script>
      $(document).ready(function(){
        $("#btn-submit").click(function(e){
          var $this = $(this);
          e.preventDefault();
          //$this.button('loading');
          $.ajaxblock();
          $.ajax({
            data: { "ndni" : $("#ndni").val() },
            type: "POST",
            dataType: "json",
            url: "Reniec/example/consulta.php",
          }).done(function( data, textStatus, jqXHR ){
            if(data['success']!="false" && data['success']!=false)
            {
              $("#json_code").text(JSON.stringify(data, null, '\t'));
              if(typeof(data['result'])!='undefined')
              {
                $("#CodVerificacion").val( data["result"]["CodVerificacion"] );
                $("#DNI").val( data["result"]["DNI"] );
                $("#Nombre").val( data["result"]["Nombre"] );
                $("#Materno").val( data["result"]["Materno"] );
                $("#Paterno").val( data["result"]["Paterno"] );
              }
              //$this.button('reset');
              $.ajaxunblock();
            }
            else
            {
              if(typeof(data['msg'])!='undefined')
              {
                alert( data['msg'] );
              }
              //$this.button('reset');
              $.ajaxunblock();
            }
          }).fail(function( jqXHR, textStatus, errorThrown ){
            alert( "Solicitud fallida:" + textStatus );
            $this.button('reset');
            $.ajaxunblock();
          });
        });
      });
    </script>
  </body>
</html>